﻿using System;
namespace OnlineShop_4M_Models
{
	public class ShoppingCart
	{
		public int ProductId { get; set; }
	}
}

